"""
video_tools.py — engine for Tool 2 (Analyse a Specific Video)
=============================================================
Reuses the niche engine (yt_dashboard) for every stat so the velocity/age logic
is never forked (Plan §1, §3a). The honest constraints from the plan are baked in:
  - clips are nominated from TRANSCRIPT CONTENT, not audience-retention data (§3c)
  - "risk hints" are advertiser-friendliness HINTS from text, never a copyright
    oracle (§3d)
  - editing style isn't detected; we surface watchable winners + text patterns (§3e)

Split by verifiability:
  PURE (unit-tested): parse_video_id, mine_description, segments_to_text,
                      transcript_wpm, opening_hook, risk_hints, place_in_niche,
                      similar_winners, build_clip_prompt, build_comment_prompt
  LIVE (needs keys/network, graceful fallback): fetch_video, fetch_niche_peers,
                      fetch_transcript, nominate_clips, fetch_top_comments
"""

import re

import yt_dashboard as engine

# ----------------------------------------------------------------- URL / ID
_ID_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")


def parse_video_id(url_or_id):
    """Accept a raw 11-char ID or any common YouTube URL form and return the ID.
    Returns None if nothing id-shaped is found."""
    s = (url_or_id or "").strip()
    if not s:
        return None
    if _ID_RE.match(s):
        return s
    # youtu.be/<id>, /watch?v=<id>, /shorts/<id>, /embed/<id>, /live/<id>
    m = re.search(r"(?:v=|/shorts/|/embed/|/live/|youtu\.be/)([A-Za-z0-9_-]{11})", s)
    if m:
        return m.group(1)
    # last resort: any 11-char token in the path
    m = re.search(r"([A-Za-z0-9_-]{11})", s)
    return m.group(1) if m else None


def _t_link(video_id, seconds):
    return f"https://www.youtube.com/watch?v={video_id}&t={int(seconds)}s"


# ----------------------------------------------------------------- description mining
_TS_RE = re.compile(r"^\s*\(?(\d{1,2}:\d{2}(?::\d{2})?)\)?\s*[-–—:]?\s*(.+?)\s*$")
_HASHTAG_RE = re.compile(r"#\w+")
_URL_RE = re.compile(r"https?://[^\s)>\]]+")
_SPONSOR_HINT = re.compile(
    r"\b(sponsor|sponsored|use code|promo code|discount code|affiliate|"
    r"thanks to|brought to you by|ad\b|#ad|paid partnership)\b", re.I)


def _ts_to_seconds(ts):
    parts = [int(p) for p in ts.split(":")]
    if len(parts) == 2:
        return parts[0] * 60 + parts[1]
    return parts[0] * 3600 + parts[1] * 60 + parts[2]


def mine_description(text, video_id=None):
    """Pull the structured signal out of a description (fully official API data, §3b):
    creator chapter timestamps, hashtags, links, sponsor hints, and the hook line."""
    text = text or ""
    lines = [ln.rstrip() for ln in text.splitlines()]

    chapters = []
    for ln in lines:
        m = _TS_RE.match(ln)
        if not m:
            continue
        label = m.group(2).strip()
        if not label or _URL_RE.match(label):
            continue
        secs = _ts_to_seconds(m.group(1))
        ch = {"t": m.group(1), "seconds": secs, "label": label}
        if video_id:
            ch["url"] = _t_link(video_id, secs)
        chapters.append(ch)
    # a real chapter list is monotonic and starts at/near 0 — guard against false hits
    if chapters:
        starts_low = chapters[0]["seconds"] <= 5
        monotonic = all(chapters[i]["seconds"] <= chapters[i + 1]["seconds"]
                        for i in range(len(chapters) - 1))
        if not (starts_low and monotonic and len(chapters) >= 2):
            chapters = []   # not a genuine chapter list; drop rather than mislead

    hashtags = _HASHTAG_RE.findall(text)
    links = _URL_RE.findall(text)
    hook = next((ln.strip() for ln in lines if ln.strip()), "")
    return {
        "chapters": chapters,
        "hashtags": list(dict.fromkeys(hashtags)),
        "links": list(dict.fromkeys(links)),
        "sponsor_mentions": bool(_SPONSOR_HINT.search(text)),
        "hook_line": hook,
    }


# ----------------------------------------------------------------- transcript helpers
def segments_to_text(segments):
    """[{text, start, duration}, ...] -> one string."""
    return " ".join((s.get("text") or "").replace("\n", " ").strip()
                    for s in (segments or [])).strip()


def transcript_wpm(segments):
    """Words per minute over the transcript — a PACING PROXY, not a measure of
    editing (§3e). Honest label is applied in the UI."""
    if not segments:
        return None
    words = sum(len((s.get("text") or "").split()) for s in segments)
    last = segments[-1]
    end = (last.get("start") or 0) + (last.get("duration") or 0)
    minutes = end / 60.0
    if minutes <= 0:
        return None
    return round(words / minutes, 1)


def opening_hook(segments, seconds=10):
    """The transcript text from the first N seconds — the spoken hook (§3e)."""
    out = []
    for s in (segments or []):
        if (s.get("start") or 0) <= seconds:
            out.append((s.get("text") or "").strip())
        else:
            break
    return " ".join(out).strip()


def parse_pasted_transcript(text):
    """Turn a MANUALLY PASTED transcript into the same segment shape the API returns,
    so every downstream feature (wpm, hook, risk, clips) works identically.

    Handles the two shapes people actually paste:
      A) YouTube 'Show transcript' — a timestamp then its line, e.g. '0:05 some text'
         or the timestamp on its own line with text on the next.
      B) Plain text with no timestamps — kept as one block (start=0); time-based
         reads (wpm, 'first 10s') are then unavailable and the UI says so.

    Returns {segments, text, has_timestamps}. Durations are estimated from the gap to
    the next timestamp so transcript_wpm has a sensible total length.
    """
    text = (text or "").strip()
    if not text:
        return {"segments": [], "text": "", "has_timestamps": False}

    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    ts_re = re.compile(r"^\(?(\d{1,2}:\d{2}(?::\d{2})?)\)?\s*(.*)$")
    segments, pending = [], None
    for ln in lines:
        m = ts_re.match(ln)
        if m and m.group(1):
            secs = _ts_to_seconds(m.group(1))
            rest = m.group(2).strip()
            if rest:
                segments.append({"start": secs, "text": rest, "duration": 0})
            else:
                pending = secs
        elif pending is not None:
            segments.append({"start": pending, "text": ln, "duration": 0})
            pending = None
        elif segments and segments[-1]["start"] == 0 and not _has_ts(segments):
            segments[-1]["text"] += " " + ln      # continuation of plain text
        elif segments:
            segments[-1]["text"] += " " + ln      # wrapped line under last timestamp
        else:
            segments.append({"start": 0, "text": ln, "duration": 0})

    has_ts = _has_ts(segments)
    if not has_ts:
        # collapse to a single block so wpm/hook can clearly report "no timing"
        joined = " ".join(s["text"] for s in segments).strip()
        segments = [{"start": 0, "text": joined, "duration": 0}]
    else:
        # estimate each segment's duration from the gap to the next start
        for i in range(len(segments) - 1):
            gap = segments[i + 1]["start"] - segments[i]["start"]
            segments[i]["duration"] = max(gap, 0.5)
        words_last = len(segments[-1]["text"].split())
        segments[-1]["duration"] = max(2.0, words_last / 2.5)  # ~150 wpm guess

    return {"segments": segments,
            "text": " ".join(s["text"] for s in segments).strip(),
            "has_timestamps": has_ts}


def _has_ts(segments):
    return any((s.get("start") or 0) > 0 for s in segments)


# ----------------------------------------------------------------- risk hints (TEXT only)
# Advertiser-friendliness HINTS from transcript text. This is NOT Content ID and NOT
# a copyright/strike predictor (§3d). Common profanity only (for the yellow-icon hint);
# deliberately no slurs are enumerated here.
_PROFANITY = {"damn", "hell", "crap", "ass", "bitch", "shit", "fuck", "fucking",
              "bastard", "dick", "piss"}
_SENSITIVE = {"kill", "death", "blood", "gun", "shoot", "violence", "drug", "suicide",
              "war", "abuse"}
_MUSIC_HINT = re.compile(
    r"\b(official music video|feat\.|ft\.|remix|soundtrack|prod\.|"
    r"original song|lyrics|cover of)\b", re.I)


def risk_hints(text):
    """Returns labelled HINTS, never verdicts. The caller must present them as
    'things to check', not 'YouTube will flag this'."""
    text = text or ""
    words = re.findall(r"[A-Za-z']+", text.lower())
    n = len(words) or 1
    prof = sum(1 for w in words if w in _PROFANITY)
    sens = sorted({w for w in words if w in _SENSITIVE})
    prof_density = round(prof / n * 1000, 2)   # per 1000 words
    if prof == 0:
        ad_hint = "no profanity detected in transcript"
    elif prof_density < 1:
        ad_hint = "occasional profanity — usually fine, but check"
    else:
        ad_hint = "frequent profanity — may get limited ads (yellow icon); check"
    return {
        "profanity_count": prof,
        "profanity_per_1000_words": prof_density,
        "ad_friendliness_hint": ad_hint,
        "sensitive_keywords": sens,
        "music_reuse_hint": bool(_MUSIC_HINT.search(text)),
        "disclaimer": ("Hints from transcript TEXT only — not Content ID, not a "
                       "copyright/strike prediction. Verify in YouTube Studio."),
    }


# ----------------------------------------------------------------- niche placement (age-fair)
def place_in_niche(video, peers):
    """Where does this video sit vs similar-age peers in its niche? Reuses the engine's
    age-banded baseline so it's age-fair (Plan §6.1). 'peers' are enriched video dicts
    (same format as a dataset's videos). Returns a multiplier + the band used."""
    pool = [p for p in peers if p.get("id") != video.get("id")] + [video]
    band_median, bands, overall = engine._age_banded_baseline(pool)
    bm = band_median(video)
    vpd = video.get("views_per_day") or 0
    return {
        "views_per_day": vpd,
        "similar_age_median": round(bm) if bm else None,
        "vs_similar_age": round(vpd / bm, 2) if bm else None,
        "overall_median": round(overall) if overall else None,
        "n_peers": len(pool) - 1,
        "n_bands": len(bands),
    }


def similar_winners(peers, video, k=8):
    """The age-fair top videos in the same niche+format — 'watch how these are cut'
    (§3e). Reuses the engine's age-fair scoring so 'winner' isn't just 'youngest'."""
    same_format = [p for p in peers
                   if bool(p.get("is_short")) == bool(video.get("is_short"))
                   and p.get("id") != video.get("id")]
    scored = engine._age_fair_scores(same_format)
    scored.sort(key=lambda v: v.get("_pattern_score", 0), reverse=True)
    out = []
    for v in scored[:k]:
        out.append({
            "title": v.get("title"), "channel": v.get("channel"),
            "url": v.get("url", f"https://www.youtube.com/watch?v={v.get('id', '')}"),
            "views": v.get("views"), "duration_sec": v.get("duration_sec"),
            "age_fair_score": round(v.get("_pattern_score", 0), 2),
            "is_question": "?" in (v.get("title") or ""),
        })
    return out


def place_vs_channel(video, channel_videos):
    """The comparison that actually means something: is this a hit FOR THIS CHANNEL?
    Compares the video against the channel's OWN recent videos (age-fair), which
    controls for channel size — unlike comparing a huge channel to random niche videos.
    """
    pool = [v for v in channel_videos if v.get("id") != video.get("id")]
    if not pool:
        return None
    full = pool + [video]
    band_median, bands, overall = engine._age_banded_baseline(full)
    bm = band_median(video)
    vpd = video.get("views_per_day") or 0
    return {
        "vs_channel_typical": round(vpd / bm, 2) if bm else None,
        "channel_median_vpd": round(bm) if bm else None,
        "n_channel_videos": len(pool),
        "channel": video.get("channel"),
    }


_CMT_TS = re.compile(r"\b(\d{1,2}:\d{2}(?::\d{2})?)\b")


def mine_comment_moments(comments, top=8):
    """The closest honest thing to retention data: which timestamps does the AUDIENCE
    keep pointing at in the comments? People quote the best bits ('19:35 was gold').
    Returns moments sorted by how many comments cite them. PURE."""
    from collections import defaultdict
    hits = defaultdict(list)
    for c in (comments or []):
        for m in _CMT_TS.findall(c or ""):
            parts = [int(p) for p in m.split(":")]
            secs = parts[0] * 60 + parts[1] if len(parts) == 2 else \
                parts[0] * 3600 + parts[1] * 60 + parts[2]
            snippet = (c or "").strip().replace("\n", " ")
            hits[(m, secs)].append(snippet[:140])
    moments = [{"t": t, "seconds": s, "mentions": len(v), "sample": v[0]}
               for (t, s), v in hits.items()]
    moments.sort(key=lambda x: (-x["mentions"], x["seconds"]))
    return moments[:top]


def analyze_title(video, winners):
    """Light, honest title read vs the niche winners (titles drive clicks). PURE."""
    title = video.get("title") or ""
    words = title.split()
    win_lens = [len((w.get("title") or "").split()) for w in (winners or [])
                if w.get("title")]
    import statistics as _s
    win_median = round(_s.median(win_lens)) if win_lens else None
    return {
        "word_count": len(words),
        "char_count": len(title),
        "has_number": any(ch.isdigit() for ch in title),
        "is_question": "?" in title,
        "has_allcaps_word": any(w.isupper() and len(w) > 2 for w in words),
        "winners_median_words": win_median,
        "vs_winners": (None if win_median is None else
                       ("shorter than" if len(words) < win_median
                        else "longer than" if len(words) > win_median
                        else "same length as")),
    }


def build_teardown_prompt(video, mined_desc, hook, comment_moments,
                          comment_themes, winners, user_niche=""):
    """The synthesis that makes the tool useful: tie every signal into 'why this worked
    and what to STEAL for your content'. PURE (builds the prompt)."""
    win = "\n".join(f"- {w.get('title','')} ({w.get('age_fair_score','?')}× age-fair)"
                    for w in (winners or [])[:6]) or "(none)"
    moments = "\n".join(f"- {m['t']} (cited by {m['mentions']} comments): {m['sample']}"
                        for m in (comment_moments or [])[:6]) or "(none found)"
    chapters = "\n".join(f"- {c['t']} {c['label']}" for c in
                         (mined_desc or {}).get("chapters", [])[:15]) or "(none)"
    niche_line = (f"The viewer makes content about: {user_niche}. Tailor every 'steal "
                  f"this' point to THAT niche.\n" if user_niche.strip() else "")
    return f"""You are a sharp YouTube strategist. Analyse why this video performs and what \
a creator should STEAL from it. Be concrete and specific — no generic advice.

{niche_line}
VIDEO: "{video.get('title')}" by {video.get('channel')}
Performance: {video.get('views', 0):,} views, {video.get('views_per_day', 0):,}/day, \
{video.get('age_days', 0)} days old.

Opening hook (spoken, first ~10s): "{hook[:400]}"

Creator's own chapter structure:
{chapters}

Moments the AUDIENCE flagged in comments (closest thing to retention data):
{moments}

What comments said landed/missed:
{(comment_themes or '(not analysed)')[:1500]}

Age-fair top performers in the same lane:
{win}

Respond in markdown, tight and actionable:
## Why it works
3-4 bullets — the actual mechanics (hook, structure, pacing, topic choice).
## Steal this
3-5 concrete moves the viewer should copy{', applied to their niche' if user_niche.strip() else ''}.
## Title & packaging
One line on the title/structure pattern worth reusing.
Keep it under 250 words. No fluff."""


def video_teardown(video, mined_desc, hook, comment_moments, comment_themes,
                   winners, user_niche=""):
    """LIVE (Claude). The one-call synthesis. Returns {text, cost_usd} or {error}."""
    prompt = build_teardown_prompt(video, mined_desc, hook, comment_moments,
                                   comment_themes, winners, user_niche)
    try:
        res = engine._call_claude(prompt, max_tokens=900)
        return {"text": res["text"], "cost_usd": res["cost_usd"]}
    except Exception as e:
        return {"error": str(e)}


def build_summary_prompt(video, transcript_text, mined_desc):
    """Plain 'what was this video about' summary — distinct from the teardown (which is
    about ideas/styles to steal). PURE."""
    chapters = "\n".join(f"- {c['t']} {c['label']}" for c in
                         (mined_desc or {}).get("chapters", [])[:20]) or "(none)"
    body = (transcript_text or "")[:11000]
    src = ("the transcript below" if body else
           "the title, description and chapters (no transcript available)")
    return f"""Summarise what this YouTube video is ABOUT, based on {src}. This is a plain \
content summary — what's covered and the main points — NOT advice.

TITLE: "{video.get('title')}" by {video.get('channel')}

Creator chapters:
{chapters}

Transcript:
{body if body else '(no transcript — rely on title/description/chapters)'}

Respond in markdown:
## In one line
A single sentence: what this video is.
## What it covers
4-7 bullets of the actual topics/points, in order.
## Takeaway
1-2 sentences: the main thing a viewer walks away knowing.
Summarise only what's present — do not invent details."""


def summarize_video(video, transcript_text, mined_desc):
    """LIVE (Claude). Returns {text, cost_usd} or {error}."""
    prompt = build_summary_prompt(video, transcript_text, mined_desc)
    try:
        res = engine._call_claude(prompt, max_tokens=700)
        return {"text": res["text"], "cost_usd": res["cost_usd"]}
    except Exception as e:
        return {"error": str(e)}


# ----------------------------------------------------------------- AI prompts
def build_clip_prompt(video_meta, segments, moments=None):
    """Prompt to nominate Short-worthy clips, rate each clip's Short potential, and cross-
    reference what the AUDIENCE already flagged (safest bets). Honesty label kept (§3c)."""
    lines = []
    for s in (segments or []):
        start = int(s.get("start") or 0)
        mm, ss = divmod(start, 60)
        lines.append(f"[{mm:02d}:{ss:02d}] {(s.get('text') or '').strip()}")
    body = "\n".join(lines)[:12000]   # keep prompt bounded
    title = video_meta.get("title", "(unknown)")
    flagged = ""
    if moments:
        ts = ", ".join(f"{m['t']} (×{m['mentions']})" for m in moments[:10])
        flagged = (f"\nThe AUDIENCE already quoted these timestamps in comments — clips "
                   f"covering them are the SAFEST Short bets: {ts}\n")
    return f"""You are a short-form editor. Below is the TIMESTAMPED TRANSCRIPT of a \
YouTube video titled "{title}". Nominate 4-7 candidate moments that could become Shorts.

You do NOT have audience-retention or "most replayed" data — judge from the content \
(a strong hook, a payoff, a funny or surprising beat, a self-contained moment).
{flagged}
Transcript:
{body}

Respond in markdown, one bullet per clip, EXACTLY in this shape:
- **start–end (mm:ss, ~N sec)** — **Short potential: High/Medium/Low** — one line why it \
works; suggested Short title; "self-contained" or "needs setup"; add "🔥 audience-flagged" \
if it overlaps an audience-quoted timestamp above.
Begin by stating these are suggested from transcript content, not audience-retention data. \
End with one line: which single clip is the best Short to make first, and why."""


def build_comment_prompt(comments, title="(unknown)"):
    joined = "\n".join(f"- {c}" for c in (comments or [])[:80])[:8000]
    return f"""Below are top comments on the YouTube video "{title}". Cluster them into \
themes: what landed, what people disliked, and what they're asking for next. Do not invent \
comments; summarise only what's here.

{joined}

Respond in markdown: ## What landed, ## What missed, ## What they want next."""


# ----------------------------------------------------------------- LIVE calls (graceful)
def fetch_video(video_id):
    """One video's enriched stats. LIVE (YouTube API). Returns enriched dict or raises."""
    vids = engine.get_videos_details([video_id])
    if not vids:
        return None
    subs = engine.get_channel_subs([vids[0]["channel_id"]])
    engine.enrich(vids, subs)
    v = vids[0]
    # get_videos_details doesn't copy the description/tags — grab them (1 cheap unit)
    try:
        data = engine._get("videos", {"part": "snippet", "id": video_id})
        items = data.get("items", [])
        if items:
            v["description"] = items[0]["snippet"].get("description", "")
            v["tags"] = items[0]["snippet"].get("tags", [])
    except Exception:
        v.setdefault("description", "")
    return v


def fetch_niche_peers(keyword, per_format=50, region_label="All regions"):
    """Recent niche peers for placement/similar-winners. LIVE. Reuses fetch_dataset so
    caching + age handling are identical to Tool 1."""
    ds = engine.fetch_dataset(keyword, balanced=True, videos_per_format=per_format,
                              region_label=region_label)
    return ds["videos"], ds.get("cost", 0), ds.get("from_cache", False)


def fetch_channel_recent(channel_id, n=25):
    """The channel's own recent uploads, enriched — for the 'is this a hit FOR THEM?'
    comparison. LIVE. Costs ~100 (search) + a couple of units."""
    ids = engine.search_ids("", max_results=n, order="date",
                            region={"channelId": channel_id})
    ids = ids[:n]
    if not ids:
        return []
    vids = engine.get_videos_details(ids)
    subs = engine.get_channel_subs([channel_id])
    engine.enrich(vids, subs)
    return vids


def fetch_transcript(video_id, db_path=None):
    """LIVE + cached. Tries the cache, then youtube-transcript-api. ALWAYS returns a
    dict; a silent/blocked/missing transcript yields available=False with a reason
    (Plan §3b: 'No transcript available.' — done, move on)."""
    import storage
    cached = storage.get_cached_transcript(video_id,
                                           **({"db_path": db_path} if db_path else {}))
    if cached:
        return cached

    result = {"video_id": video_id, "available": False, "lang": None,
              "text": "", "segments": [], "reason": ""}
    try:
        from youtube_transcript_api import YouTubeTranscriptApi
    except Exception:
        result["reason"] = ("transcript library not installed — run "
                            "`pip install youtube-transcript-api`")
        return result   # not cached: it's an environment issue, not a video fact

    try:
        # support both old (.get_transcript) and new (.fetch) library APIs
        if hasattr(YouTubeTranscriptApi, "get_transcript"):
            raw = YouTubeTranscriptApi.get_transcript(video_id)
            segments = [{"text": r.get("text", ""), "start": r.get("start", 0),
                         "duration": r.get("duration", 0)} for r in raw]
        else:
            fetched = YouTubeTranscriptApi().fetch(video_id)
            segments = [{"text": s.text, "start": s.start, "duration": s.duration}
                        for s in fetched]
        result.update(available=True, segments=segments,
                      text=segments_to_text(segments))
    except Exception as e:
        result["reason"] = f"No transcript available ({type(e).__name__})."

    storage.cache_transcript(video_id, result["available"], result.get("lang"),
                             result.get("text", ""), result.get("segments", []),
                             **({"db_path": db_path} if db_path else {}))
    return result


def nominate_clips(video_meta, segments, moments=None):
    """LIVE (Claude). Returns {text, cost_usd} or {error}."""
    if not segments:
        return {"error": "No transcript — cannot nominate clips."}
    prompt = build_clip_prompt(video_meta, segments, moments)
    try:
        res = engine._call_claude(prompt, max_tokens=1300)
        return {"text": res["text"], "cost_usd": res["cost_usd"]}
    except Exception as e:
        return {"error": str(e)}


def fetch_top_comments(video_id, limit=80, db_path=None):
    """LIVE (YouTube API) + cached. Returns list of comment strings (graceful: [] if
    comments are disabled)."""
    import storage
    cached = storage.get_cached_comments(video_id,
                                         **({"db_path": db_path} if db_path else {}))
    if cached is not None:
        return cached
    out = []
    try:
        data = engine._get("commentThreads",
                           {"part": "snippet", "videoId": video_id,
                            "maxResults": min(limit, 100), "order": "relevance"})
        for item in data.get("items", []):
            sn = item["snippet"]["topLevelComment"]["snippet"]
            out.append(sn.get("textOriginal", ""))
    except Exception:
        out = []   # comments disabled or unavailable
    storage.cache_comments(video_id, out, **({"db_path": db_path} if db_path else {}))
    return out
